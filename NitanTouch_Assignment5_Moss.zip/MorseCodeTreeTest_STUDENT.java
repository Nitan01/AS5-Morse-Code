package application;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;

public class MorseCodeTreeTest_STUDENT {
    private MorseCodeTree tree;

    // Set up the MorseCodeTree before each test
    @Before
    public void setUp() {
        tree = new MorseCodeTree();
    }

    // Clean up the tree after each test
    @After
    public void tearDown() {
        tree = null;
    }

    @Test
    public void testGetRoot() {
        // Test the root of the Morse Code Tree
        assertNotNull("Root should not be null", tree.getRoot());
        assertEquals("Root should have empty string as data", "", tree.getRoot().getData());
    }

    @Test
    public void testInsertAndFetch() {
        // Insert and fetch a letter using Morse code
        tree.insert("....", "h");  // Morse for 'h'
        assertEquals("Fetching '....' should return 'h'", "h", tree.fetch("...."));
        
        // Try inserting a new value and verify
        tree.insert(".--", "w");  // Morse for 'w'
        assertEquals("Fetching '.--' should return 'w'", "w", tree.fetch(".--"));
    }

    @Test
    public void testBuildTree() {
        // Test if the MorseCodeTree is built correctly by checking the root and a few known nodes
        assertEquals("Fetching '.' should return 'e'", "e", tree.fetch("."));
        assertEquals("Fetching '-' should return 't'", "t", tree.fetch("-"));
        assertEquals("Fetching '.-' should return 'a'", "a", tree.fetch(".-"));
        assertEquals("Fetching '--' should return 'm'", "m", tree.fetch("--"));
    }

    @Test
    public void testDeleteNotSupported() {
        // Test that delete operation throws an exception
        try {
            tree.delete("e");
            fail("Delete operation should not be supported");
        } catch (UnsupportedOperationException e) {
            // Test passes if exception is thrown
        }
    }

    @Test
    public void testUpdateNotSupported() {
        // Test that update operation throws an exception
        try {
            tree.update();
            fail("Update operation should not be supported");
        } catch (UnsupportedOperationException e) {
            // Test passes if exception is thrown
        }
    }

    @Test
    public void testInsertExistingCode() {
        // Insert a new code and fetch it, verify that it does not overwrite existing codes
        tree.insert("-.-.", "c");
        assertEquals("Fetching '-.-.' should return 'c'", "c", tree.fetch("-.-."));
        
    }
}
