package application;

/** 
 * Node for a Tree, has a left and right child.
 * @param <T> The data type for the data the TreeNode will hold.
 */
public class TreeNode<T> {
    
    TreeNode<T> left;
    TreeNode<T> right;
    private T data;
    
    /** 
     * Generic Constructor for the TreeNode
     * 
     * @param dataNode The data to store in the node.
     */
    public TreeNode(T dataNode) {
        left = null;
        right = null;
        data = dataNode;
    }
    
    /** 
     * Copy constructor for the TreeNode.
     * 
     * @param node The node to be copied.
     */
    public TreeNode(TreeNode<T> node) {
        this(node.getData());
        left = node.left;
        right = node.right;
    }
    
    /** 
     * Gets the data from the node.
     * 
     * @return The data within this TreeNode.
     */
    public T getData() {
        return data;
    }
}