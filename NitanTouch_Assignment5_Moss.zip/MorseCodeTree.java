package application;

import java.util.ArrayList;
import java.util.Arrays;

/** Tree that holds Morse Code in a way that's easy to read
 * 
 * @author nitan
 *
 */
public class MorseCodeTree implements LinkedConverterTreeInterface<String> {
    private TreeNode<String> root;
    
    /** Default constructor that builds the tree and creates the root */
    public MorseCodeTree() {
        root = new TreeNode<>("");
        buildTree();
    }

    /** @return The tree's root */
    @Override
    public TreeNode<String> getRoot() {
        return root;
    }

    /** Sets the root of the MorseCodeTree */
    @Override
    public void setRoot(TreeNode<String> newNode) {
        root = newNode;
    }

    /** Adds element to the correct position in the tree based on the code */
    @Override
    public void insert(String code, String letter) {
        addNode(root, code, letter);
    }

    /** Recursively adds an element to the correct position in the tree *  
     * @param root The node's root
	 *  @param code The path of the letter, in morse code
	 *  @param letter The letter to add
	 */
    @Override
    public void addNode(TreeNode<String> root, String code, String letter) {
        if (code.length() == 1) {
            if (code.charAt(0) == '.') {
                root.left = new TreeNode<>(letter);
            } else if (code.charAt(0) == '-') {
                root.right = new TreeNode<>(letter);
            }
        } else {
            if (code.charAt(0) == '.') {
                if (root.left == null) {
                    root.left = new TreeNode<>("");
                }
                addNode(root.left, code.substring(1), letter);
            } else if (code.charAt(0) == '-') {
                if (root.right == null) {
                    root.right = new TreeNode<>("");
                }
                addNode(root.right, code.substring(1), letter);
            }
        }
    }

    /** Fetch the data in the tree based on the code 
     * @param code The code for the letter you want
	 * @return The english letter corresponding to the morse code
	 **/
    @Override
    public String fetch(String code) {
        return fetchNode(root, code);
    }

    /** Recursively fetches the data of the TreeNode that corresponds with the code */
    @Override
    public String fetchNode(TreeNode<String> root, String code) {
        if (code.length() == 1) {
            return code.charAt(0) == '.' ? root.left.getData() : root.right.getData();
        } else {
            if (code.charAt(0) == '.') {
                return fetchNode(root.left, code.substring(1));
            } else {
                return fetchNode(root.right, code.substring(1));
            }
        }
    }

    /** Operation not supported */
    @Override
    public MorseCodeTree delete(String data) throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Delete operation is not supported");
    }

    /** Operation not supported */
    @Override
    public MorseCodeTree update() throws UnsupportedOperationException {
        throw new UnsupportedOperationException("Update operation is not supported");
    }

    /** Builds the tree with all letters in the alphabet and the morse code */
    @Override
    public void buildTree() {
        insert(".", "e");
        insert("-", "t");
        insert("..", "i");
        insert(".-", "a");
        insert("-.", "n");
        insert("--", "m");
        insert("...", "s");
        insert("..-", "u");
        insert(".-.", "r");
        insert(".--", "w");
        insert("-..", "d");
        insert("-.-", "k");
        insert("--.", "g");
        insert("---", "o");
        insert("....", "h");
        insert("...-", "v");
        insert("..-.", "f");
        insert(".-..", "l");
        insert(".--.", "p");
        insert(".---", "j");
        insert("-...", "b");
        insert("-..-", "x");
        insert("-.-.", "c");
        insert("-.--", "y");
        insert("--..", "z");
        insert("--.-", "q");
    }

    /** return ArrayList of the items in the tree, in order */
    @Override
    public ArrayList<String> toArrayList() {
        ArrayList<String> list = new ArrayList<>();
        LNRoutputTraversal(root, list);
        return list;
    }

    /** Recursively puts the contents of the tree in an ArrayList in LNR (Inorder) 
     * @param root The current node's root
	 * @param list The arraylist to add items
	 **/
    
    @Override
    public void LNRoutputTraversal(TreeNode<String> root, ArrayList<String> list) {
        if (root != null) {
            LNRoutputTraversal(root.left, list);
            list.add(root.getData());
            LNRoutputTraversal(root.right, list);
        }
    }
}