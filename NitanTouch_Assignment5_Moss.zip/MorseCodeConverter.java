package application;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Converter Utility class to convert morse code into readable text.
 * Each letter in Morse code is delimited by a space (' '), and words are delimited by a '/'.
 * 
 * @author nitan
 */
public class MorseCodeConverter {

    // Initialize the MorseCodeTree, which will be used for fetching English letters from Morse code.
    static MorseCodeTree morseCodeTree = new MorseCodeTree();

    /**
     * Default constructor for MorseCodeConverter.
     */
    public MorseCodeConverter() {
        // Constructor is intentionally empty as the tree is already statically initialized.
    }

    /**
     * Converts a file of Morse code into English.
     * 
     * @param codeFile The file to read Morse code from.
     * @return The English text translated from the Morse code in the file.
     * @throws FileNotFoundException If the specified file is not found.
     */
    public static String convertToEnglish(File codeFile) throws FileNotFoundException {
        if (!codeFile.exists()) {
            throw new FileNotFoundException("File not found");
        }

        // Read the file and accumulate the contents
        Scanner fileReader = new Scanner(codeFile);
        StringBuilder fileContent = new StringBuilder();

        while (fileReader.hasNextLine()) {
            fileContent.append(fileReader.nextLine()).append(" ");
        }

        fileReader.close();
        return convertToEnglish(fileContent.toString());
    }

    /**
     * Converts Morse code into English. Each letter is delimited by a space (' '),
     * and words are delimited by a '/'.
     * 
     * @param code The code to be decoded, or turned into english.
     * @return The English translation of the Morse code.
     */
    public static String convertToEnglish(String code) {
        StringBuilder englishText = new StringBuilder();
        String[] codeArray = code.split(" ");

        for (String morseSymbol : codeArray) {
            if (morseSymbol.equals("/")) {
                // A '/' in Morse code represents a space between words
                englishText.append(" ");
            } else {
                // Fetch the corresponding English character from the MorseCodeTree
                englishText.append(morseCodeTree.fetch(morseSymbol));
            }
        }

        return englishText.toString();
    }

    /**
     * Prints the tree, for debugging purposes
     * 
     * @return A string with the tree's data in-order.
     */
    public static String printTree() {
        StringBuilder treeData = new StringBuilder();
        for (String item : morseCodeTree.toArrayList()) {
            treeData.append(item).append(" ");
        }

        return treeData.toString();  // Trim to remove any trailing space
    }
}